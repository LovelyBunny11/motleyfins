package com.cosmocat.motleyfins.data;

import com.cosmocat.motleyfins.MotleyFins;
import net.minecraft.class_1792;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class MotleyFinsTags {

    public static void init() {}

    private static class_6862<class_2248> blockTag(String name) {
        return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(MotleyFins.MOD_ID, name));
    }

    private static class_6862<class_1792> itemTag(String name) {
        return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(MotleyFins.MOD_ID, name));
    }

    private static class_6862<class_1959> biomeTag(String name) {
        return class_6862.method_40092(class_7924.field_41236, class_2960.method_60655(MotleyFins.MOD_ID, name));
    }

    public class Items {
        public static final class_6862<class_1792> PARROTFISH_FOOD = itemTag("parrotfish_food");
    }

    public class Biomes {
        public static final class_6862<class_1959> SPAWNS_PARROTFISH = biomeTag("spawns_parrotfish");
    }
}
