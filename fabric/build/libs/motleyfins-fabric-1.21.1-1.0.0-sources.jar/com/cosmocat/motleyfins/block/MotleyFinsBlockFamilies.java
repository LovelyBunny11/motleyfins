package com.cosmocat.motleyfins.block;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.stream.Stream;
import net.minecraft.class_2248;
import net.minecraft.class_5794;
import net.minecraft.class_7923;

public class MotleyFinsBlockFamilies {
    private static final Map<class_2248, class_5794> MAP = Maps.newHashMap();
    public static final class_5794 WHITE_SANDSTONE =
            familyBuilder(MotleyFinsBlocks.WHITE_SANDSTONE)
            .method_33497(MotleyFinsBlocks.WHITE_SANDSTONE_WALL)
            .method_33493(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS)
            .method_33492(MotleyFinsBlocks.WHITE_SANDSTONE_SLAB)
            .method_33486(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE)
            .method_36544(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)
            .method_33488().method_33481();

    public static final class_5794 CUT_WHITE_SANDSTONE =
            familyBuilder(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)
                    .method_33492(MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB).method_33481();

    public static final class_5794 SMOOTH_WHITE_SANDSTONE =
            familyBuilder(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE)
                    .method_33493(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS)
                    .method_33492(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB).method_33481();

    private static class_5794.class_5795 familyBuilder(class_2248 baseBlock) {
        class_5794.class_5795 blockfamily$builder = new class_5794.class_5795(baseBlock);
        class_5794 blockfamily = MAP.put(baseBlock, blockfamily$builder.method_33481());
        if (blockfamily != null) {
            throw new IllegalStateException("Duplicate family definition for " + class_7923.field_41175.method_10221(baseBlock));
        } else {
            return blockfamily$builder;
        }
    }

    public static Stream<class_5794> getAllFamilies() {
        return MAP.values().stream();
    }

}
