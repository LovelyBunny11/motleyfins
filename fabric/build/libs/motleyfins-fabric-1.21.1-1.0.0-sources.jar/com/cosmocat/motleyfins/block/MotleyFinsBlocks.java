package com.cosmocat.motleyfins.block;

import com.cosmocat.motleyfins.MotleyFins;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2544;
import net.minecraft.class_2766;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.class_8805;
import net.minecraft.class_8812;
import net.minecraft.world.level.block.*;

public class MotleyFinsBlocks {

    public static final class_2248 WHITE_SAND = registerBlock("white_sand",
            new class_8812(new class_8805(12893615), class_4970.class_2251.method_9637().method_31710(class_3620.field_16003).method_51368(class_2766.field_12643).method_9632(0.5F).method_9626(class_2498.field_11526)));
    public static final class_2248 WHITE_SANDSTONE = registerBlock("white_sandstone",
            new class_2248(class_4970.class_2251.method_9637().method_31710(class_3620.field_16003).method_51368(class_2766.field_12653).method_29292().method_9632(0.8F)));
    public static final class_2248 WHITE_SANDSTONE_STAIRS = registerBlock("white_sandstone_stairs",
            new class_2510(MotleyFinsBlocks.WHITE_SANDSTONE.method_9564(), class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 WHITE_SANDSTONE_SLAB = registerBlock("white_sandstone_slab",
            new class_2482(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 WHITE_SANDSTONE_WALL = registerBlock("white_sandstone_wall",
            new class_2544(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 CHISELED_WHITE_SANDSTONE = registerBlock("chiseled_white_sandstone",
            new class_2248(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 SMOOTH_WHITE_SANDSTONE = registerBlock("smooth_white_sandstone",
            new class_2248(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 SMOOTH_WHITE_SANDSTONE_STAIRS = registerBlock("smooth_white_sandstone_stairs",
            new class_2510(MotleyFinsBlocks.WHITE_SANDSTONE.method_9564(), class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 SMOOTH_WHITE_SANDSTONE_SLAB = registerBlock("smooth_white_sandstone_slab",
            new class_2482(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 CUT_WHITE_SANDSTONE = registerBlock("cut_white_sandstone",
            new class_2248(class_4970.class_2251.method_9630(MotleyFinsBlocks.WHITE_SANDSTONE)));
    public static final class_2248 CUT_WHITE_SANDSTONE_SLAB = registerBlock("cut_white_sandstone_slab",
            new class_2482(class_4970.class_2251.method_9630(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)));

    public static class_2248 registerBlock(String name, class_2248 block) {
        class_2960 id = class_2960.method_60655(MotleyFins.MOD_ID, name);
        class_1747 blockItem = new class_1747(block, new class_1792.class_1793());
        class_2378.method_10230(class_7923.field_41178, id, blockItem);


        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    public static void init() {}
}
