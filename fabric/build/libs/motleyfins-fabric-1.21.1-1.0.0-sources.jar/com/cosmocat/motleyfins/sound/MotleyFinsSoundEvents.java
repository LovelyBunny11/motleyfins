package com.cosmocat.motleyfins.sound;

import com.cosmocat.motleyfins.MotleyFins;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class MotleyFinsSoundEvents {
    public static Map<class_5321<@NotNull class_3414>, class_3414> REGISTRIES = new HashMap<>();

    public static final class_3414 PARROTFISH_AMBIENT = registerSound("entity.parrotfish.ambient");
    public static final class_3414 PARROTFISH_DEATH = registerSound("entity.parrotfish.death");
    public static final class_3414 PARROTFISH_FLOP = registerSound("entity.parrotfish.flop");
    public static final class_3414 PARROTFISH_HURT = registerSound("entity.parrotfish.hurt");
    public static final class_3414 PARROTFISH_EAT = registerSound("entity.parrotfish.eat");

    public static void init() {}

    public static class_3414 registerSound(String name) {
        class_5321<@NotNull class_3414> key = class_5321.method_29179(class_7924.field_41225, class_2960.method_60655(MotleyFins.MOD_ID, name));
        class_3414 soundEvent = class_3414.method_47908(class_2960.method_60655(MotleyFins.MOD_ID, name));

        REGISTRIES.put(key, soundEvent);
        return class_2378.method_39197(class_7923.field_41172, key, soundEvent);
    }
}
