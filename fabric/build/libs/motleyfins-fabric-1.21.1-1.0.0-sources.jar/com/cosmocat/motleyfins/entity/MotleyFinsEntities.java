package com.cosmocat.motleyfins.entity;

import com.cosmocat.motleyfins.MotleyFins;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

import static com.cosmocat.motleyfins.MotleyFins.MOD_ID;

public class MotleyFinsEntities {

    public static final class_1299<@NotNull Parrotfish> PARROTFISH =
            registerEntity("parrotfish", class_1299.class_1300.method_5903(Parrotfish::new, class_1311.field_24460)
                    .method_17687(0.8F, 0.55F).method_55687(0.25F));

    public static void init() {}

    public static <T extends class_1297> class_1299<@NotNull T> registerEntity(String name, class_1299.class_1300<@NotNull T> builder) {
        return class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(MOD_ID, name), builder.method_5905(name));
    }
}
