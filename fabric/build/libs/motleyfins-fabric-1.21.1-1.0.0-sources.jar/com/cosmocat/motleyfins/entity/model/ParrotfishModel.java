package com.cosmocat.motleyfins.entity.model;

import com.cosmocat.motleyfins.MotleyFins;
import com.cosmocat.motleyfins.entity.Parrotfish;
import com.cosmocat.motleyfins.entity.animation.ParrotfishAnimations;
import net.minecraft.class_2960;
import net.minecraft.class_5597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

public class ParrotfishModel<T extends Parrotfish> extends class_5597<T> {
    public static final class_5601 PARROTFISH_LAYER = new class_5601(class_2960.method_60655(MotleyFins.MOD_ID, "parrotfish"), "main");

    private final class_630 root;
    private final class_630 body;
    private final class_630 body_front;
    private final class_630 beak;
    private final class_630 right_fin;
    private final class_630 left_fin;
    private final class_630 body_back;
    private final class_630 tail_fin;

    public ParrotfishModel(class_630 root) {
        this.root = root.method_32086("root");
        this.body = this.root.method_32086("body");
        this.body_front = this.body.method_32086("body_front");
        this.beak = this.body_front.method_32086("beak");
        this.right_fin = this.body_front.method_32086("right_fin");
        this.left_fin = this.body_front.method_32086("left_fin");
        this.body_back = this.body.method_32086("body_back");
        this.tail_fin = this.body_back.method_32086("tail_fin");
    }

    public static class_5607 createBodyLayer() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();

        class_5610 root = partdefinition.method_32117("root", class_5606.method_32108(), class_5603.method_32090(0.0F, 21.0F, -0.5F));

        class_5610 body = root.method_32117("body", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

        class_5610 body_front = body.method_32117("body_front", class_5606.method_32108().method_32101(0, 0).method_32098(-1.5556F, -2.7222F, -5.0556F, 3.0F, 6.0F, 5.0F, new class_5605(0.0F))
                .method_32101(16, 14).method_32098(-1.5556F, -2.7222F, -6.0556F, 3.0F, 2.0F, 1.0F, new class_5605(0.0F))
                .method_32101(13, 20).method_32098(-0.0556F, -5.7222F, -4.0556F, 0.0F, 3.0F, 4.0F, new class_5605(0.0F))
                .method_32101(6, 24).method_32098(-0.0556F, 3.2778F, -2.0556F, 0.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0556F, -0.2778F, -0.4444F));

        class_5610 beak = body_front.method_32117("beak", class_5606.method_32108().method_32101(24, 14).method_32098(-1.0F, 0.0F, -0.49F, 2.0F, 3.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-0.0556F, -0.7222F, -5.5556F));

        class_5610 right_fin = body_front.method_32117("right_fin", class_5606.method_32108().method_32101(16, 0).method_32098(-3.0F, -2.0F, 0.0F, 3.0F, 4.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(-1.5556F, 1.2778F, -1.0556F, 0.0F, 0.9599F, 0.0F));

        class_5610 left_fin = body_front.method_32117("left_fin", class_5606.method_32108().method_32101(16, 4).method_32098(0.0F, -2.0F, 0.0F, 3.0F, 4.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(1.4444F, 1.2778F, -1.0556F, 0.0F, -0.9599F, 0.0F));

        class_5610 body_back = body.method_32117("body_back", class_5606.method_32108().method_32101(0, 11).method_32098(-2.0F, -3.0F, 0.0F, 3.0F, 6.0F, 7.0F, new class_5605(0.01F))
                .method_32101(0, 18).method_32098(-0.5F, -6.0F, 0.0F, 0.0F, 3.0F, 6.0F, new class_5605(0.0F))
                .method_32101(0, 24).method_32098(-0.5F, 3.0F, 3.0F, 0.0F, 1.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, 0.0F, -0.5F));

        class_5610 tail_fin = body_back.method_32117("tail_fin", class_5606.method_32108().method_32101(16, 3).method_32098(0.0F, -3.0F, 0.0F, 0.0F, 6.0F, 5.0F, new class_5605(0.0F)), class_5603.method_32090(-0.5F, 0.0F, 7.0F));

        return class_5607.method_32110(meshdefinition, 64, 64);
    }

    @Override
    public void setupAnim(T parrotfish, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.method_32008().method_32088().forEach(class_630::method_41923);
        this.method_43781(parrotfish.swimAnimationState, ParrotfishAnimations.SWIM, ageInTicks);
        this.method_43781(parrotfish.flopAnimationState, ParrotfishAnimations.FLOP, ageInTicks);
        this.method_43781(parrotfish.swimPoopAnimationState, ParrotfishAnimations.SWIM_SAND, ageInTicks);
    }

    @Override
    public class_630 method_32008() {
        return this.root;
    }
}