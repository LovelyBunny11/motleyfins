package com.cosmocat.motleyfins.entity.render;

import com.cosmocat.motleyfins.MotleyFins;
import com.cosmocat.motleyfins.entity.Parrotfish;
import com.cosmocat.motleyfins.entity.model.ParrotfishModel;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import org.jetbrains.annotations.NotNull;

public class ParrotfishRenderer extends class_927<@NotNull Parrotfish, @NotNull ParrotfishModel<Parrotfish>> {
    private static final class_2960 RED_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/red.png");
    private static final class_2960 BLUE_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/blue.png");
    private static final class_2960 GREEN_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/green.png");
    private static final class_2960 CYAN_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/cyan.png");
    private static final class_2960 GRAY_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/gray.png");
    private static final class_2960 TRICOLOR_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/tricolor.png");
    private static final class_2960 YELLOWTAIL_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/yellowtail.png");
    private static final class_2960 STOPLIGHT_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/stoplight.png");
    private static final class_2960 REDBAND_LOCATION = class_2960.method_60655(MotleyFins.MOD_ID,"textures/entity/parrotfish/redband.png");

    public ParrotfishRenderer(class_5617.class_5618 context) {
        super(context, new ParrotfishModel<>(context.method_32167(ParrotfishModel.PARROTFISH_LAYER)), 0.5f);
    }

    @Override
    public @NotNull class_2960 getTextureLocation(@NotNull Parrotfish parrotfish) {
        return switch (parrotfish.getVariant()) {
            case RED -> RED_LOCATION;
            case BLUE -> BLUE_LOCATION;
            case GREEN -> GREEN_LOCATION;
            case CYAN -> CYAN_LOCATION;
            case GRAY -> GRAY_LOCATION;
            case TRICOLOR -> TRICOLOR_LOCATION;
            case YELLOWTAIL -> YELLOWTAIL_LOCATION;
            case STOPLIGHT -> STOPLIGHT_LOCATION;
            case REDBAND -> REDBAND_LOCATION;
        };
    }
}