package com.cosmocat.motleyfins.entity.animation;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

public class ParrotfishAnimations {
    public static final class_7184 SWIM = class_7184.class_7185.method_41818(1.0F).method_41817()
            .method_41820("right_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("left_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("tail_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, -10.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, -22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, 11.25F), class_7179.class_7181.field_37885),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_back", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_back", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884),
                    new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.875F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884)
            ))
            .method_41820("body", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 5.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, -5.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, 5.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 5.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41821();

    public static final class_7184 FLOP = class_7184.class_7185.method_41818(0.8333F).method_41817()
            .method_41820("right_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2917F, class_7187.method_41829(-3.6807F, 22.4497F, -3.553F), class_7179.class_7181.field_37885),
                    new class_7186(0.4583F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5833F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.7083F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 35.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("left_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, -12.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2917F, class_7187.method_41829(0.0F, 17.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5417F, class_7187.method_41829(0.0F, -12.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.7083F, class_7187.method_41829(0.0F, 17.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("tail_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.0833F, class_7187.method_41829(0.0F, 0.0F, -10.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2083F, class_7187.method_41829(0.0F, -22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.3333F, class_7187.method_41829(0.0F, 0.0F, 11.25F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, -10.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.625F, class_7187.method_41829(0.0F, -22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, 0.0F, 11.25F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_front", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.0833F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2083F, class_7187.method_41829(0.0F, 7.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.625F, class_7187.method_41829(0.0F, 7.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_back", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 15.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.0833F, class_7187.method_41829(-0.3878F, 4.4231F, -5.015F), class_7179.class_7181.field_37885),
                    new class_7186(0.2083F, class_7187.method_41829(0.0F, -15.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2917F, class_7187.method_41829(-0.2932F, -3.6669F, 5.3713F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(0.0F, 15.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(-0.2952F, 3.6121F, -5.3967F), class_7179.class_7181.field_37885),
                    new class_7186(0.625F, class_7187.method_41829(0.0F, -15.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.7083F, class_7187.method_41829(-0.3579F, -4.5385F, 5.6451F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 15.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 5.0F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.3333F, class_7187.method_41829(0.0F, -7.5F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5417F, class_7187.method_41829(0.0F, 5.0F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.75F, class_7187.method_41829(0.0F, -7.5F, -90.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41829(0.0F, 0.0F, -90.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41823(0.0F, 2.25F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.6667F, class_7187.method_41823(0.0F, 2.25F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.8333F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41821();

    public static final class_7184 SWIM_SAND = class_7184.class_7185.method_41818(0.5F).method_41817()
            .method_41820("right_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.375F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("left_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.375F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("tail_fin", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, -10.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, -22.5F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, 11.25F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 22.5F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_back", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, -10.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 10.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("body_back", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884),
                    new class_7186(0.0625F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.125F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.1875F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884),
                    new class_7186(0.3125F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.4375F, class_7187.method_41823(0.0F, 0.0F, -0.075F), class_7179.class_7181.field_37884),
                    new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, -0.1F), class_7179.class_7181.field_37884)
            ))
            .method_41820("body", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 2.5F), class_7179.class_7181.field_37885),
                    new class_7186(0.125F, class_7187.method_41829(0.0F, 0.0F, -2.5F), class_7179.class_7181.field_37885),
                    new class_7186(0.25F, class_7187.method_41829(0.0F, 0.0F, 2.5F), class_7179.class_7181.field_37885),
                    new class_7186(0.375F, class_7187.method_41829(0.0F, 0.0F, -2.5F), class_7179.class_7181.field_37885),
                    new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 2.5F), class_7179.class_7181.field_37885)
            ))
            .method_41821();
}
