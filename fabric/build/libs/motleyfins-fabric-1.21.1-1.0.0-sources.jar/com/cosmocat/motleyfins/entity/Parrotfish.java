package com.cosmocat.motleyfins.entity;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import com.cosmocat.motleyfins.data.MotleyFinsTags;
import com.cosmocat.motleyfins.item.MotleyFinsItems;
import com.cosmocat.motleyfins.particle.MotleyFinsParticles;
import com.cosmocat.motleyfins.sound.MotleyFinsSoundEvents;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1391;
import net.minecraft.class_1425;
import net.minecraft.class_1480;
import net.minecraft.class_1542;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3542;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5761;
import net.minecraft.class_5819;
import net.minecraft.class_7094;
import net.minecraft.class_7995;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.IntFunction;

public class Parrotfish extends class_1425 {

    protected static final Variant[] COMMON_VARIANTS = List.of(Variant.BLUE, Variant.TRICOLOR, Variant.YELLOWTAIL, Variant.STOPLIGHT, Variant.REDBAND).toArray(Variant[]::new);

    public static final class_2940<@NotNull Integer> DATA_TYPE_ID = class_2945.method_12791(Parrotfish.class, class_2943.field_13327);
    public static final class_2940<@NotNull Boolean> IS_DROPPING_SAND = class_2945.method_12791(Parrotfish.class, class_2943.field_13323);

    private int ticksAfterLastSandDrop = 0;
    private int sandDroppingTicks = 0;
    private int sandDroppingCooldown = 0;
    private boolean isSchool = true;

    public Parrotfish(class_1299<? extends @NotNull class_1425> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public double method_23320() {
        return super.method_23320();
    }

    public static class_5132.@NotNull class_5133 method_26828() {
        return class_1308.method_26828().method_26868(class_5134.field_23719, 1.0F).method_26868(class_5134.field_23716, 5.0F);
    }

    @Override
    protected void method_5959() {
        super.method_5959();
        this.field_6201.method_6277(1, new class_1391(this, 1.2, (itemStack) -> itemStack.method_31573(MotleyFinsTags.Items.PARROTFISH_FOOD), false));
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().method_8608()) {
            this.setupAnimationStates();
        }
    }

    private @NotNull class_1542 createWhiteSandToDrop() {
        double d0 = this.method_23320() - (double)0.3F;
        class_1542 itementity = new class_1542(this.method_37908(), this.method_23317(), d0, this.method_23321(), new class_1799(MotleyFinsBlocks.WHITE_SAND.method_8389()));
        itementity.method_6982(40);
        itementity.method_6981(this);

        float f8 = class_3532.method_15374(this.method_36455() * ((float)Math.PI / 180F));
        float f2 = class_3532.method_15362(this.method_36455() * ((float)Math.PI / 180F));
        float f3 = class_3532.method_15374( this.method_36454() * ((float)Math.PI / 180F));
        float f4 = class_3532.method_15362(this.method_36454() * ((float)Math.PI / 180F));
        float f5 = this.field_5974.method_43057() * ((float)Math.PI * 2F);
        float f6 = 0.02F * this.field_5974.method_43057();
        itementity.method_18800(-((double)(-f3 * f2 * 0.3F) + Math.cos(f5) * (double)f6), -(-f8 * 0.3F + 0.1F + (this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.1F), -((double)(f4 * f2 * 0.3F) + Math.sin(f5) * (double)f6));

        return itementity;
    }

    public class_1542 dropWhiteSand() {
        if (this.method_37908().method_8608()) {
            this.method_6104(class_1268.field_5808);
            return null;
        } else {
            class_1542 itementity = this.createWhiteSandToDrop();
            this.method_37908().method_8649(itementity);

            return itementity;
        }
    }

    @Override
    public void method_6007() {
        super.method_6007();
        ++this.ticksAfterLastSandDrop;
        class_1542 item = null;

        if (this.isDroppingSand()) {
            ++this.sandDroppingTicks;
            if ((this.field_5974.method_43051(0, 30) == 0)) {
                item = this.dropWhiteSand();
                this.method_5783(class_3417.field_15197, 0.25F, 3.0F);
                this.ticksAfterLastSandDrop = 0;
            } if (this.sandDroppingTicks > 200) {
                this.setDroppingSand(false);
                this.sandDroppingTicks = 0;
                this.sandDroppingCooldown = 6000;
            }
            if (this.field_5974.method_43048(5) == 0) {
                int d = this.field_5974.method_43051(1, 5);
                for (int i = 0; i < d; i++) {
                    this.method_37908().method_8421(this, (byte)19);
                }
            }
        } else {
            if (this.sandDroppingCooldown > 0) {
                --this.sandDroppingCooldown;
            }
        }

        if (item != null) {
            if (this.ticksAfterLastSandDrop == 10) {
                this.method_37908().method_8421(this, (byte)19);
            }
        }
    }

    // Data //

    @Override
    protected void method_5693(class_2945.@NotNull class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_TYPE_ID, 0);
        builder.method_56912(IS_DROPPING_SAND, false);
    }

    public void method_5652(@NotNull class_2487 compound) {
        super.method_5652(compound);
        compound.method_10569("Variant", this.getVariant().id());
        compound.method_10556("IsDroppingSand", this.field_6011.method_12789(IS_DROPPING_SAND));
        compound.method_10569("SandDroppingTicks", this.sandDroppingTicks);
        compound.method_10569("SandDroppingCooldown", this.sandDroppingCooldown);
    }

    public void method_5749(@NotNull class_2487 compound) {
        super.method_5749(compound);
        this.setVariant(Variant.byId(compound.method_10550("Variant")));
        this.setDroppingSand(compound.method_10577("IsDroppingSand"));
        this.sandDroppingTicks = compound.method_10550("SandDroppingTicks");
        this.sandDroppingCooldown = compound.method_10550("SandDroppingCooldown");
    }

    // White Sand Obtaining //

    @Override
    protected @NotNull class_1269 method_5992(class_1657 player, @NotNull class_1268 hand) {
        class_1799 itemstack = player.method_5998(hand);
        if (this.canFeed()) {
            if (isFood(itemstack)) {
                if (!this.method_37908().field_9236) {
                    this.setDroppingSand(true);
                    this.usePlayerItem(player, itemstack);
                    this.method_37908().method_8421(this, (byte)18);
                    this.method_56078(MotleyFinsSoundEvents.PARROTFISH_EAT);

                    return class_1269.field_5812;
                }

                if (this.method_37908().field_9236) {
                    return class_1269.field_21466;
                }
            }
        }

        return class_5761.method_35169(player, hand, this).orElse(super.method_5992(player, hand));
    }


    protected void usePlayerItem(class_1657 player, class_1799 stack) {
        stack.method_57008(1, player);
    }

    private boolean canFeed() {
        return this.method_5799() && !(this.isDroppingSand()) && (this.sandDroppingCooldown == 0);
    }

    public static boolean isFood(class_1799 itemstack) {
        return itemstack.method_31573(MotleyFinsTags.Items.PARROTFISH_FOOD);
    }

    public boolean isDroppingSand() {
        return this.field_6011.method_12789(IS_DROPPING_SAND);
    }

    void setDroppingSand(boolean isDroppingSand) {
        this.field_6011.method_12778(IS_DROPPING_SAND, isDroppingSand);
    }

    public void method_5711(byte event) {
        if (event == 18) {
            for(int i = 0; i < 7; ++i) {
                double d0 = this.field_5974.method_43059() * 0.02;
                double d1 = this.field_5974.method_43059() * 0.02;
                double d2 = this.field_5974.method_43059() * 0.02;
                this.method_37908().method_8406(class_2398.field_11211, this.method_23322(1.0F), this.method_23319(), this.method_23325(1.0F), d0, d1, d2);
            }
        } else if (event == 19) {
            for(int i = 0; i < 7; ++i) {
                double d0 = this.field_5974.method_43059() * 0.02;
                double d1 = this.field_5974.method_43059() * 0.02;
                double d2 = this.field_5974.method_43059() * 0.02;
                this.method_37908().method_8406(MotleyFinsParticles.WHITE_SAND, this.method_23317(), this.method_23318(), this.method_23321(), d0, d1, d2);
            }
        }  else {
            super.method_5711(event);
        }

    }

    // Bucketable //

    @Override
    public @NotNull class_1799 method_6452() {
        return new class_1799(MotleyFinsItems.PARROTFISH_BUCKET);
    }

    @Override
    public void method_6455(@NotNull class_1799 stack) {
        super.method_6455(stack);
        class_9279.method_57452(class_9334.field_49610, stack, (tag) -> tag.method_10569("Variant", this.getVariant().id));
        class_9279.method_57452(class_9334.field_49610, stack, (tag) -> tag.method_10556("IsDroppingSand", this.isDroppingSand()));
        class_9279.method_57452(class_9334.field_49610, stack, (tag) -> tag.method_10569("SandDroppingTicks", this.sandDroppingTicks));
        class_9279.method_57452(class_9334.field_49610, stack, (tag) -> tag.method_10569("SandDroppingCooldown", this.sandDroppingCooldown));
    }

    public void method_35170(@NotNull class_2487 tag) {
        super.method_35170(tag);
        if (tag.method_10545("Variant")) {
            this.setVariant(Variant.byId(tag.method_10550("Variant")));
        } if (tag.method_10545("IsDroppingSand")) {
            this.setDroppingSand(tag.method_10577("IsDroppingSand"));
        } if (tag.method_10545("SandDroppingTicks")) {
            this.sandDroppingTicks = tag.method_10550("SandDroppingTicks");
        } if (tag.method_10545("SandDroppingCooldown")) {
            this.sandDroppingCooldown = tag.method_10550("SandDroppingCooldown");
        }
    }

    // Sounds //

    @Override
    protected class_3414 method_5994() {
        return MotleyFinsSoundEvents.PARROTFISH_AMBIENT;
    }

    @Override
    protected class_3414 method_6002() {
        return MotleyFinsSoundEvents.PARROTFISH_DEATH;
    }

    @Override
    protected @NotNull class_3414 method_6457() {
        return MotleyFinsSoundEvents.PARROTFISH_FLOP;
    }

    @Override
    protected class_3414 method_6011(@NotNull class_1282 pDamageSource) {
        return MotleyFinsSoundEvents.PARROTFISH_HURT;
    }

    // Animations //

    public final class_7094 swimAnimationState = new class_7094();

    public final class_7094 flopAnimationState = new class_7094();

    public final class_7094 swimPoopAnimationState = new class_7094();

    public void setupAnimationStates() {
        if (this.method_5799()) {
            if (flopAnimationState.method_41327()) {
                flopAnimationState.method_41325();
            } if (this.isDroppingSand()) {
                if (swimAnimationState.method_41327()) {
                    swimAnimationState.method_41325();
                } if (!swimPoopAnimationState.method_41327()) {
                    swimPoopAnimationState.method_41322(this.field_6012);
                }
            } else {
                if (swimPoopAnimationState.method_41327()) {
                    swimPoopAnimationState.method_41325();
                } if (!swimAnimationState.method_41327()) {
                    swimAnimationState.method_41322(this.field_6012);
                }
            }
        } else {
            if (swimAnimationState.method_41327()) {
                swimAnimationState.method_41325();
            } if (!flopAnimationState.method_41327()) {
                flopAnimationState.method_41322(this.field_6012);
            }
        }
    }

    // Variant //

    public void setVariant(Variant variant) {
        this.field_6011.method_12778(DATA_TYPE_ID, variant.id);
    }

    public Variant getVariant() {
        return Variant.byId(this.field_6011.method_12789(DATA_TYPE_ID));
    }

    // Spawning //

    @Override
    public boolean method_5969(int p_478570_) {
        return !this.isSchool;
    }

    @Override
    public class_1315 method_5943(@NotNull class_5425 level, @NotNull class_1266 difficulty, @NotNull class_3730 spawnType, class_1315 spawnGroupData) {
        spawnGroupData = super.method_5943(level, difficulty, spawnType, spawnGroupData);
        class_5819 randomSource = level.method_8409();

        Variant parrotfishVariant;
        if (spawnGroupData instanceof ParrotfishGroupData parrotfishGroupData) {
            parrotfishVariant = parrotfishGroupData.variant;
        } else if ((double)randomSource.method_43057() < 0.75) {
            parrotfishVariant = class_156.method_27173(COMMON_VARIANTS, randomSource);
            spawnGroupData = new ParrotfishGroupData(this, parrotfishVariant);
        } else {
            this.isSchool = false;
            parrotfishVariant = Variant.byId(randomSource.method_43048((Variant.values().length) + 1));
        }

        this.setVariant(parrotfishVariant);
        return spawnGroupData;
    }

    public static boolean checkParrotfishSpawnRules(class_1299<@NotNull Parrotfish> parrotfish, class_1936 level, class_3730 spawnType, class_2338 blockPos, class_5819 randomSource) {
        return (level.method_8316(blockPos.method_10074()).method_15767(class_3486.field_15517) || level.method_8320(blockPos.method_10074()).method_26164(class_3481.field_15461)) &&
                (level.method_8316(blockPos).method_15767(class_3486.field_15517) || level.method_8320(blockPos).method_26164(class_3481.field_15488)) &&
                level.method_8316(blockPos.method_10084()).method_15767(class_3486.field_15517) &&
                class_1480.method_38986(parrotfish, level, spawnType, blockPos, randomSource);
    }

    static class ParrotfishGroupData extends class_1426 {
        final Variant variant;

        ParrotfishGroupData(Parrotfish parrotfish, Variant variant) {
            super(parrotfish);
            this.variant = variant;
        }
    }

    public enum Variant implements class_3542 {

        RED(0, "red"),
        BLUE(1, "blue"),
        GREEN(2, "green"),
        CYAN(3, "cyan"),
        GRAY(4, "gray"),
        TRICOLOR(5, "tricolor"),
        YELLOWTAIL(6, "yellowtail"),
        STOPLIGHT(7, "stoplight"),
        REDBAND(8, "redband");

        private static final IntFunction<Variant> BY_ID = class_7995.method_47915(Variant::id, values(), RED);

        final int id;
        private final String name;
        private final class_2561 displayName;

        Variant(int pId, String pName) {
            this.id = pId;
            this.name = pName;
            this.displayName = class_2561.method_43471("entity.motleyfins.parrotfish.type." + this.name);
        }

        public @NotNull String method_15434() {
            return this.name;
        }

        public class_2561 displayName() {
            return this.displayName;
        }

        public int id() {
            return this.id;
        }

        public static Variant byId(int pId) {
            return BY_ID.apply(pId);
        }
    }

}
