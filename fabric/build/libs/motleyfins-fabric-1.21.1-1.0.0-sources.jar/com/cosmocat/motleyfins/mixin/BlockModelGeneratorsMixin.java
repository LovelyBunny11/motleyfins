package com.cosmocat.motleyfins.mixin;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import com.google.common.collect.ImmutableMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_4910;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;

@Mixin(value = class_4910.class)
public class BlockModelGeneratorsMixin {
    @Shadow
    @Final
    public Map<class_2248, class_4946> texturedModels = ImmutableMap.<class_2248, class_4946>builder().put(class_2246.field_9979, class_4946.field_23057.get(class_2246.field_9979)).put(class_2246.field_10344, class_4946.field_23057.get(class_2246.field_10344)).put(class_2246.field_10467, class_4946.method_25920(class_4944.method_25866(class_2246.field_9979, "_top"))).put(class_2246.field_10483, class_4946.method_25920(class_4944.method_25866(class_2246.field_10344, "_top"))).put(class_2246.field_10361, class_4946.field_23038.get(class_2246.field_9979).method_25917((textureMapping) -> textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(class_2246.field_10361)))).put(class_2246.field_10518, class_4946.field_23038.get(class_2246.field_10344).method_25917((textureMapping) -> textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(class_2246.field_10518)))).put(class_2246.field_10153, class_4946.field_23038.get(class_2246.field_10153)).put(class_2246.field_9978, class_4946.method_25920(class_4944.method_25866(class_2246.field_10153, "_bottom"))).put(class_2246.field_23869, class_4946.field_23959.get(class_2246.field_23869)).put(class_2246.field_28888, class_4946.field_23959.get(class_2246.field_28888)).put(class_2246.field_10044, class_4946.field_23038.get(class_2246.field_10044).method_25917((textureMapping) -> textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(class_2246.field_10044)))).put(class_2246.field_10292, class_4946.field_23038.get(class_2246.field_10292).method_25917((textureMapping) -> {
                textureMapping.method_25868(class_4945.field_23013, class_4944.method_25866(class_2246.field_9979, "_top"));
                textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(class_2246.field_10292));
            })).put(class_2246.field_10117, class_4946.field_23038.get(class_2246.field_10117).method_25917((textureMapping) -> {
                textureMapping.method_25868(class_4945.field_23013, class_4944.method_25866(class_2246.field_10344, "_top"));
                textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(class_2246.field_10117));
            })).put(class_2246.field_47039, class_4946.field_23959.get(class_2246.field_47039)).put(class_2246.field_47034, class_4946.field_23959.get(class_2246.field_47034))
            // Adding MotleyFins Blocks //
            .put(MotleyFinsBlocks.WHITE_SANDSTONE, class_4946.field_23057.get(MotleyFinsBlocks.WHITE_SANDSTONE)).put(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE, class_4946.method_25920(class_4944.method_25866(MotleyFinsBlocks.WHITE_SANDSTONE, "_top"))).put(MotleyFinsBlocks.CUT_WHITE_SANDSTONE, class_4946.field_23038.get(MotleyFinsBlocks.WHITE_SANDSTONE).method_25917((textureMapping) -> textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)))).put(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE, class_4946.field_23038.get(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE).method_25917((textureMapping) -> {
                textureMapping.method_25868(class_4945.field_23013, class_4944.method_25866(MotleyFinsBlocks.WHITE_SANDSTONE, "_top"));
                textureMapping.method_25868(class_4945.field_23018, class_4944.method_25860(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE));
            })).build();

}
