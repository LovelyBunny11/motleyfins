package com.cosmocat.motleyfins.mixin;

import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1425;
import net.minecraft.class_1474;
import net.minecraft.class_1767;
import net.minecraft.class_1937;

@Mixin(value = class_1474.class)
public abstract class TropicalFishMixin extends class_1425 {

    @Shadow
    @Final
    public static List<class_1474.class_7992> COMMON_VARIANTS;

    public TropicalFishMixin(class_1299<? extends @NotNull class_1425> entityType, class_1937 level) {
        super(entityType, level);
    }

    static {
        ArrayList<class_1474.class_7992> common_variants = new ArrayList<>(COMMON_VARIANTS);
        common_variants.removeIf((variant) -> variant.equals(new class_1474.class_7992(class_1474.class_1475.field_6890, class_1767.field_7955, class_1767.field_7947)));
        common_variants.removeIf((variant) -> variant.equals(new class_1474.class_7992(class_1474.class_1475.field_6890, class_1767.field_7955, class_1767.field_7954)));
        COMMON_VARIANTS = List.copyOf(common_variants);
    }
}
