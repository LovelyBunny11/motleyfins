package com.cosmocat.motleyfins;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import com.cosmocat.motleyfins.data.MotleyFinsTags;
import com.cosmocat.motleyfins.entity.MotleyFinsEntities;
import com.cosmocat.motleyfins.entity.Parrotfish;
import com.cosmocat.motleyfins.item.MotleyFinsItems;
import com.cosmocat.motleyfins.sound.MotleyFinsSoundEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1802;
import net.minecraft.class_2902;
import net.minecraft.class_7706;
import net.minecraft.class_9169;

public class MotleyFinsFabric implements ModInitializer {
    
    @Override
    public void onInitialize() {
        MotleyFinsBlocks.init();
        MotleyFinsItems.init();
        MotleyFinsSoundEvents.init();
        MotleyFinsEntities.init();
        MotleyFins.init();
        FabricDefaultAttributeRegistry.register(MotleyFinsEntities.PARROTFISH, Parrotfish.method_26828());
        BiomeModifications.addSpawn(BiomeSelectors.tag(MotleyFinsTags.Biomes.SPAWNS_PARROTFISH), class_1311.field_24460, MotleyFinsEntities.PARROTFISH, 25, 6, 8);
        class_1317.method_20637(MotleyFinsEntities.PARROTFISH, class_9169.field_48743, class_2902.class_2903.field_13203, Parrotfish::checkParrotfishSpawnRules);
        addItemsToCreativeTabs();
    }

    private static void addItemsToCreativeTabs() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register((entries) -> {
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.CUT_WHITE_SANDSTONE);

            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE);

            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.WHITE_SANDSTONE_WALL);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.WHITE_SANDSTONE_SLAB);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS);
            entries.addAfter(class_1802.field_18887, MotleyFinsBlocks.WHITE_SANDSTONE);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register((entries) -> {
            entries.addAfter(class_1802.field_20408, MotleyFinsBlocks.WHITE_SANDSTONE);
            entries.addAfter(class_1802.field_20408, MotleyFinsBlocks.WHITE_SAND);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register((entries) -> entries.addAfter(class_1802.field_8478, MotleyFinsItems.PARROTFISH_BUCKET));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register((entries) -> entries.addAfter(class_1802.field_8846, MotleyFinsItems.PARROTFISH));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register((entries) -> entries.addAfter(class_1802.field_8274, MotleyFinsItems.PARROTFISH_SPAWN_EGG));
    }
}