package com.cosmocat.motleyfins.item;

import com.cosmocat.motleyfins.entity.MotleyFinsEntities;
import com.cosmocat.motleyfins.entity.Parrotfish;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1785;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class MotleyFinsMobBucketItem extends class_1785 {
    private final class_1299<? extends @NotNull class_1308> type;

    public MotleyFinsMobBucketItem(class_1299<? extends @NotNull class_1308> type, class_3611 content, class_3414 emptySound, class_1793 properties) {
        super(type, content, emptySound, properties);
        this.type = type;
    }

    @Override
    public void method_7851(@NotNull class_1799 stack, @NotNull class_9635 context, @NotNull List<class_2561> tooltipComponents, @NotNull class_1836 tooltipFlag) {
        if (this.type == MotleyFinsEntities.PARROTFISH) {
            class_9279 customdata = stack.method_57825(class_9334.field_49610, class_9279.field_49302);
            if (customdata.method_57458()) {
                return;
            }

            Parrotfish.Variant variant = Parrotfish.Variant.byId(customdata.method_57461().method_10550("Variant"));
            tooltipComponents.add(variant.displayName().method_27662().method_27695(class_124.field_1056, class_124.field_1080));
        }
    }
}
