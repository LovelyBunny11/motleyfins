package com.cosmocat.motleyfins.item;

import com.cosmocat.motleyfins.MotleyFins;
import com.cosmocat.motleyfins.entity.MotleyFinsEntities;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3612;
import net.minecraft.class_4176;
import net.minecraft.class_7923;

public class MotleyFinsItems {
    public static final class_1792 PARROTFISH_BUCKET = registerItem("parrotfish_bucket",
            new MotleyFinsMobBucketItem(MotleyFinsEntities.PARROTFISH, class_3612.field_15910, class_3417.field_14912, new class_1792.class_1793().method_7889(1)));

    public static final class_1792 PARROTFISH_SPAWN_EGG = registerItem("parrotfish_spawn_egg",
            new class_1826(MotleyFinsEntities.PARROTFISH, 10422810, 7710463, new class_1792.class_1793()));

    public static final class_1792 PARROTFISH = registerItem("parrotfish",
            new class_1792(new class_1792.class_1793().method_19265(class_4176.field_18628)));

    public static void init() {}

    public static class_1792 registerItem(String name, class_1792 item) {
        class_2960 itemID = class_2960.method_60655(MotleyFins.MOD_ID, name);

        return class_2378.method_10230(class_7923.field_41178, itemID, item);
    }
}
