package com.cosmocat.motleyfins.particle;

import static com.cosmocat.motleyfins.MotleyFins.MOD_ID;

import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class MotleyFinsParticles {

    public static final class_2400 WHITE_SAND = register("white_sand", false);

    public static void init() {}

    private static class_2400 register(String key, boolean overrideLimiter) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(MOD_ID, key), new class_2400(overrideLimiter));
    }
}
