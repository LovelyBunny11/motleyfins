package com.cosmocat.motleyfins.particle;

import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_761;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.NotNull;

public class WhiteSandParticle extends class_4003 {
    protected final class_4002 sprites;

    WhiteSandParticle(class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, class_4002 sprites) {
        super(level, x, y, z);
        this.field_3844 = 0.0125F;
        this.sprites = sprites;
        this.field_3852 = xSpeed;
        this.field_3869 = ySpeed;
        this.field_3850 = zSpeed;
        this.field_17867 = 0.175F * (this.field_3840.method_43057() * 0.5F + 0.5F) * 2.0F;
        this.field_3847 = 60 + this.field_3840.method_43048(12);
        this.method_18142(sprites);
    }

    @Override
    public int method_3068(float partialTick) {
        class_2338 blockPos = class_2338.method_49637(this.field_3874, this.field_3854, this.field_3871);
        return this.field_3851.method_22340(blockPos) ? class_761.method_23794(this.field_3851, blockPos) : 0;
    }

    @Override
    public void method_3069(double x, double y, double z) {
        this.method_3067(this.method_3064().method_989(x, y, z));
        this.method_3072();
    }

    @Override
    public void method_3070() {
        super.method_3070();
        this.method_18142(this.sprites);
        this.method_3083(1.0F - (float) this.field_3866 / (float) this.field_3847);
    }

    @Override
    public @NotNull class_3999 method_18122() {
        return class_3999.field_17829;
    }

    public static class Provider implements class_707<class_2400> {
        private final class_4002 sprites;

        public Provider(class_4002 sprites) {
            this.sprites = sprites;
        }

        @Override
        public @NotNull class_703 createParticle(@NotNull class_2400 simpleParticleType, @NotNull class_638 clientLevel, double d, double e, double f, double g, double h, double i) {
            return new WhiteSandParticle(clientLevel, d, e, f, g, h, i, this.sprites);
        }
    }
}
