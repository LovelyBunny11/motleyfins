package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import com.cosmocat.motleyfins.data.MotleyFinsTags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1802;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

public class MotleyFinsItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public MotleyFinsItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.@NotNull class_7874 wrapperLookup) {
        getOrCreateTagBuilder(class_3489.field_15532)
                .add(MotleyFinsBlocks.WHITE_SAND.method_8389());
        getOrCreateTagBuilder(class_3489.field_15526)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS.method_8389())
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS.method_8389());
        getOrCreateTagBuilder(class_3489.field_15535)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_SLAB.method_8389())
                .add(MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB.method_8389())
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB.method_8389());
        getOrCreateTagBuilder(class_3489.field_15560)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_WALL.method_8389());
        getOrCreateTagBuilder(MotleyFinsTags.Items.PARROTFISH_FOOD)
                .add(class_1802.field_8402)
                .add(class_1802.field_8847)
                .add(class_1802.field_8521)
                .add(class_1802.field_8474)
                .add(class_1802.field_8616)
                .add(class_1802.field_8628)
                .add(class_1802.field_8883)
                .add(class_1802.field_8538)
                .add(class_1802.field_8452)
                .add(class_1802.field_8278)
                .add(class_1802.field_8546)
                .add(class_1802.field_8214)
                .add(class_1802.field_8104)
                .add(class_1802.field_8723)
                .add(class_1802.field_8817)
                .add(class_1802.field_8856)
                .add(class_1802.field_8549)
                .add(class_1802.field_8351)
                .add(class_1802.field_8237)
                .add(class_1802.field_8381)
                .add(class_1802.field_8585)
                .add(class_1802.field_8089)
                .add(class_1802.field_8051)
                .add(class_1802.field_8462)
                .add(class_1802.field_8160)
                .add(class_1802.field_8830)
                .add(class_1802.field_8677)
                .add(class_1802.field_8698)
                .add(class_1802.field_8272)
                .add(class_1802.field_8269);
    }
}