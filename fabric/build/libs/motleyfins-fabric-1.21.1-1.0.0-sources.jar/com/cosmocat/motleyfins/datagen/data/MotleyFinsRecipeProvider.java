package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.block.MotleyFinsBlockFamilies;
import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2454;
import net.minecraft.class_5794;
import net.minecraft.class_5797;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;

public class MotleyFinsRecipeProvider extends FabricRecipeProvider {
    public MotleyFinsRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void method_10419(class_8790 recipeOutput) {
        MotleyFinsBlockFamilies.getAllFamilies().filter(class_5794::method_33478).forEach((family) ->
                generateRecipes(recipeOutput, family));
        method_46209(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.WHITE_SANDSTONE, MotleyFinsBlocks.WHITE_SAND);
        method_32804(class_7800.field_40634, MotleyFinsBlocks.WHITE_SANDSTONE_SLAB, class_1856.method_8091(MotleyFinsBlocks.WHITE_SANDSTONE, MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE)).method_33530("has_white_sandstone", method_10426(MotleyFinsBlocks.WHITE_SANDSTONE)).method_33530("has_chiseled_white_sandstone", method_10426(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE)).method_10431(recipeOutput);
        method_32808(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS, class_1856.method_8091(MotleyFinsBlocks.WHITE_SANDSTONE, MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE, MotleyFinsBlocks.CUT_WHITE_SANDSTONE)).method_33530("has_white_sandstone", method_10426(MotleyFinsBlocks.WHITE_SANDSTONE)).method_33530("has_chiseled_white_sandstone", method_10426(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE)).method_33530("has_cut_white_sandstone", method_10426(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)).method_10431(recipeOutput);
        method_32811(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.CUT_WHITE_SANDSTONE, MotleyFinsBlocks.WHITE_SANDSTONE);
        method_32809(recipeOutput, class_7800.field_40635, MotleyFinsBlocks.WHITE_SANDSTONE_WALL, MotleyFinsBlocks.WHITE_SANDSTONE);
        method_32812(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE, MotleyFinsBlocks.WHITE_SANDSTONE_SLAB);

        class_2454.method_17802(class_1856.method_8091(MotleyFinsBlocks.WHITE_SANDSTONE), class_7800.field_40634, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE.method_8389(), 0.1F, 200).method_10469("has_white_sandstone", method_10426(MotleyFinsBlocks.WHITE_SANDSTONE)).method_10431(recipeOutput);

        method_33717(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.CUT_WHITE_SANDSTONE, MotleyFinsBlocks.WHITE_SANDSTONE);
        method_33715(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.WHITE_SANDSTONE_SLAB, MotleyFinsBlocks.WHITE_SANDSTONE, 2);
        method_33715(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB, MotleyFinsBlocks.WHITE_SANDSTONE, 2);
        method_33715(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB, MotleyFinsBlocks.CUT_WHITE_SANDSTONE, 2);
        method_33717(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS, MotleyFinsBlocks.WHITE_SANDSTONE);
        method_33717(recipeOutput, class_7800.field_40635, MotleyFinsBlocks.WHITE_SANDSTONE_WALL, MotleyFinsBlocks.WHITE_SANDSTONE);
        method_33715(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE, 2);
        method_33717(recipeOutput, class_7800.field_40634, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS, MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE);
    }

    public static void generateRecipes(class_8790 recipeOutput, class_5794 blockFamily) {
        blockFamily.method_33474().forEach((variant, block) -> {
            BiFunction<class_1935, class_1935, class_5797> biFunction = field_28555.get(variant);
            class_1935 itemLike = method_33533(blockFamily, variant);
            if (biFunction != null) {
                class_5797 recipeBuilder = biFunction.apply(block, itemLike);
                blockFamily.method_33479().ifPresent((string) -> recipeBuilder.method_33529(string + (variant == class_5794.class_5796.field_33689 ? "" : "_" + variant.method_33498())));
                recipeBuilder.method_33530(blockFamily.method_33480().orElseGet(() -> method_32807(itemLike)), method_10426(itemLike));
                recipeBuilder.method_10431(recipeOutput);
            }

            if (variant == class_5794.class_5796.field_29503) {
                method_34662(recipeOutput, block, itemLike);
            }
        });
    }


    @Override
    public @NotNull String method_10321() {
        return "MotleyFinsRecipeProvider";
    }
}