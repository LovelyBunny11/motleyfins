package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.entity.MotleyFinsEntities;
import com.cosmocat.motleyfins.item.MotleyFinsItems;
import com.google.common.collect.Sets;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricLootTableProvider;
import net.fabricmc.fabric.impl.datagen.loot.FabricLootTableProviderImpl;
import net.minecraft.class_1299;
import net.minecraft.class_141;
import net.minecraft.class_173;
import net.minecraft.class_1802;
import net.minecraft.class_219;
import net.minecraft.class_2960;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7699;
import net.minecraft.class_77;
import net.minecraft.class_7789;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class MotleyFinsEntityLootTableProvider extends class_7789 implements FabricLootTableProvider {
    private final FabricDataOutput output;
    private final CompletableFuture<class_7225.class_7874> registryLookupFuture;
    private final Set<class_2960> excludedFromStrictValidation = new HashSet<>();

    public MotleyFinsEntityLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(class_7699.method_45397(), registryLookup.join());
        this.output = dataOutput;
        this.registryLookupFuture = registryLookup;
    }

    @Override
    public void method_10400() {
        this.method_46029(MotleyFinsEntities.PARROTFISH, class_52.method_324().method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_351(class_77.method_411(MotleyFinsItems.PARROTFISH).method_438(class_141.method_621(class_44.method_32448(1.0F))))).method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_351(class_77.method_411(class_1802.field_8324)).method_356(class_219.method_932(0.05F))));
    }

    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> biConsumer) {
        this.method_10400();

        for (Map.Entry<class_1299<?>, Map<class_5321<class_52>, class_52.class_53>> entry : field_40615.entrySet()) {
            class_5321<class_52> registryKey = entry.getKey().method_16351();

            if (registryKey == class_39.field_844) {
                continue;
            }

            biConsumer.accept(registryKey, entry.getValue().get(registryKey));
        }

        if (output.isStrictValidationEnabled()) {
            Set<class_2960> missing = Sets.newHashSet();

            for (class_2960 entityId : class_7923.field_41177.method_10235()) {
                if (entityId.method_12836().equals(output.getModId())) {
                    class_5321<class_52> entityLootTableId = class_7923.field_41177.method_10223(entityId).method_16351();

                    if (entityLootTableId.method_29177().method_12836().equals(output.getModId())) {
                        if (!field_40615.containsKey(entityLootTableId)) {
                            missing.add(entityId);
                        }
                    }
                }
            }

            missing.removeAll(excludedFromStrictValidation);

            if (!missing.isEmpty()) {
                throw new IllegalStateException("Missing loot table(s) for %s".formatted(missing));
            }
        }
    }

    public void excludeFromStrictValidation(class_1299<?> entityType) {
        excludedFromStrictValidation.add(class_7923.field_41177.method_10221(entityType));
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        return FabricLootTableProviderImpl.run(output, this, class_173.field_1173, this.output, registryLookupFuture);
    }

    @Override
    public String method_10321() {
        return "Entity Loot Tables";
    }
}
