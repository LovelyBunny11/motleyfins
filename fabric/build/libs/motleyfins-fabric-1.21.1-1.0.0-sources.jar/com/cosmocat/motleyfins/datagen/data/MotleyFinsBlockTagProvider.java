package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3481;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

public class MotleyFinsBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public MotleyFinsBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.@NotNull class_7874 wrapperLookup) {
        getOrCreateTagBuilder(class_3481.field_33716)
                .add(MotleyFinsBlocks.WHITE_SAND);
        getOrCreateTagBuilder(class_3481.field_33715)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_SLAB)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_WALL)
                .add(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE)
                .add(MotleyFinsBlocks.CUT_WHITE_SANDSTONE)
                .add(MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB)
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE)
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS)
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB);
        getOrCreateTagBuilder(class_3481.field_15466)
                .add(MotleyFinsBlocks.WHITE_SAND);
        getOrCreateTagBuilder(class_3481.field_15459)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS)
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS);
        getOrCreateTagBuilder(class_3481.field_15469)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_SLAB)
                .add(MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB)
                .add(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB);
        getOrCreateTagBuilder(class_3481.field_15504)
                .add(MotleyFinsBlocks.WHITE_SANDSTONE_WALL);
    }
}