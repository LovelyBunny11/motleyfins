package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class MotleyFinsBlockLootTableProvider extends FabricBlockLootTableProvider {
    public MotleyFinsBlockLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        this.method_46025(MotleyFinsBlocks.WHITE_SAND);

        this.method_46025(MotleyFinsBlocks.WHITE_SANDSTONE);
        this.method_46025(MotleyFinsBlocks.WHITE_SANDSTONE_STAIRS);
        this.method_46025(MotleyFinsBlocks.WHITE_SANDSTONE_SLAB);
        this.method_46025(MotleyFinsBlocks.WHITE_SANDSTONE_WALL);
        this.method_46025(MotleyFinsBlocks.CHISELED_WHITE_SANDSTONE);

        this.method_46025(MotleyFinsBlocks.CUT_WHITE_SANDSTONE);
        this.method_46025(MotleyFinsBlocks.CUT_WHITE_SANDSTONE_SLAB);

        this.method_46025(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE);
        this.method_46025(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_STAIRS);
        this.method_46025(MotleyFinsBlocks.SMOOTH_WHITE_SANDSTONE_SLAB);
    }
}