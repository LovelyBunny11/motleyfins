package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.data.MotleyFinsTags;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1972;
import net.minecraft.class_6957;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public class MotleyFinsBiomeTagProvider extends class_6957 {

    public MotleyFinsBiomeTagProvider(class_7784 output, CompletableFuture<class_7225.class_7874> provider) {
        super(output, provider);
    }

    @Override
    protected void method_10514(class_7225.@NotNull class_7874 provider) {
        this.method_10512(MotleyFinsTags.Biomes.SPAWNS_PARROTFISH).method_46835(class_1972.field_9408);
    }
}