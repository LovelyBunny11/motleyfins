package com.cosmocat.motleyfins.datagen.assets;

import com.cosmocat.motleyfins.block.MotleyFinsBlockFamilies;
import com.cosmocat.motleyfins.block.MotleyFinsBlocks;
import com.cosmocat.motleyfins.item.MotleyFinsItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;
import net.minecraft.class_5794;
import org.jetbrains.annotations.NotNull;

public class MotleyFinsModelProvider extends FabricModelProvider {

    public MotleyFinsModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        blockStateModelGenerator.method_25641(MotleyFinsBlocks.WHITE_SAND);
        MotleyFinsBlockFamilies.getAllFamilies().filter(class_5794::method_33477).forEach((blockFamily) -> blockStateModelGenerator.method_25650(blockFamily.method_33469()).method_33522(blockFamily));
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_25733(MotleyFinsItems.PARROTFISH_SPAWN_EGG, class_4943.field_22938);
        itemModelGenerator.method_25733(MotleyFinsItems.PARROTFISH_BUCKET, class_4943.field_22938);
        itemModelGenerator.method_25733(MotleyFinsItems.PARROTFISH, class_4943.field_22938);
    }

    @Override
    public @NotNull String method_10321() {
        return "MotleyFinsModelProvider";
    }
}