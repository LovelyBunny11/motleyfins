package com.cosmocat.motleyfins.datagen.data;

import com.cosmocat.motleyfins.entity.MotleyFinsEntities;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3483;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.CompletableFuture;

public class MotleyFinsEntityTagProvider extends FabricTagProvider.EntityTypeTagProvider {
    public MotleyFinsEntityTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.@NotNull class_7874 wrapperLookup) {
        getOrCreateTagBuilder(class_3483.field_48288).add(MotleyFinsEntities.PARROTFISH);
        getOrCreateTagBuilder(class_3483.field_29824).add(MotleyFinsEntities.PARROTFISH);
        getOrCreateTagBuilder(class_3483.field_48283).add(MotleyFinsEntities.PARROTFISH);
    }
}